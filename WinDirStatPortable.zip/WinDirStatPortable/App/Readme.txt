This directory contains files used by the portable app and should generally not be accessed directly by users except in specific instances of using plugins or other documented additions to a given app.

User files, data, or settings should not be stored within the App directory or its subdirectories. Any data stored within the App directory structure will likely be deleted on upgrades.